In order of this to work properly, install `battoexe.exe`, then run Quick Batch File Compiler once and close it.
After that, run `QBFCCrack.reg`.
When you restart Quick Batch File Compiler you'll see you have a registered version.